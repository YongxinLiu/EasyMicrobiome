#! /bin/bash

set -e


usage()
{
cat <<EOF
${txtcyn}

run_sparcc.sh by CHEN Liang

https://bitbucket.org/yonatanf/sparcc/src/05f4d3f31d778a8be2c9992cfc107cb3a4222e30?at=default

wget https://bitbucket.org/yonatanf/sparcc/get/05f4d3f31d77.zip
unzip 05f4d3f31d77.zip 
cd yonatanf-sparcc-05f4d3f31d77
sh run_sparcc.sh

Dependencies
pip install numpy==1.13.3
pip install pandas==0.20.3

Usage:

$0 options${txtrst}

${bldblu}Function${txtrst}:


${txtbld}OPTIONS${txtrst}:
	-f	OTU table 	
		${bldred}[NECESSARY]${txtrst}
	-o	Output dir
		${bldred}[NECESSARY]${txtrst}
	-n	Bootstarp number. Default 10.


EOF
}

# here goes the path to the input file
## sample-otu table needs to be a tab delimited text file where columns are samples and rows are components (e.g. OTUS, genes).
#INPUT_PATH="example/fake_data.txt"
INPUT_PATH=
## bootstraps numbers
bootnum="10"
## output directory
outdir="sparcc_result"

while getopts "hf:o:n:" OPTION
do
	case $OPTION in
		h)
			usage
			exit 1
			;;
		f)
			INPUT_PATH=$OPTARG
			;;
		o)
			outdir=$OPTARG
			;;
		n)
			bootnum=$OPTARG
			;;
		?)
			usage
			exit 1
			;;
	esac
done

if [ -z $INPUT_PATH ]; then
	usage
	exit 1
fi


mkdir -p ${outdir}/basis_corr/
mkdir -p ${outdir}/pvals/

sparcc_dir=$(dirname $(readlink -f $0))

python2.7 ${sparcc_dir}/SparCC.py ${INPUT_PATH} --cor_file=${outdir}/basis_corr/cor_sparcc.out > ${outdir}/sparcc.log

python2.7 ${sparcc_dir}/MakeBootstraps.py ${INPUT_PATH=} -n ${bootnum} -t permutation_#.txt -p ${outdir}/pvals/

# compute sparcc on resampled (with replacement) datasets
cycle=`expr ${bootnum} - 1`

for i in `seq 0 ${cycle}`
do
    python2.7 ${sparcc_dir}/SparCC.py ${outdir}/pvals/permutation_$i.txt --cor_file=${outdir}/pvals/perm_cor_$i.txt >> ${outdir}/sparcc.log 
done

# compute p-value from bootstraps
python2.7 ${sparcc_dir}/PseudoPvals.py ${outdir}/basis_corr/cor_sparcc.out ${outdir}/pvals/perm_cor_#.txt ${bootnum} -o ${outdir}/pvals/pvals_two_sided.txt -t 'two_sided'  >> ${outdir}/sparcc.log

# visualization requires parsing and thresholding the p-value OTU matrix
